# IOS Notification Fold Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/Heehe-flexboxer/pen/NWmJeJw](https://codepen.io/Heehe-flexboxer/pen/NWmJeJw).

